"""PADIM model."""



from .lightning_model import PadimLightning

__all__ = ["PadimLightning"]
