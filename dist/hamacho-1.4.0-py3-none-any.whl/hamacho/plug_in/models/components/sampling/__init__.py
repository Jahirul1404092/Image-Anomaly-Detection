"""Sampling methods."""



from .k_center_greedy import KCenterGreedy

__all__ = ["KCenterGreedy"]
