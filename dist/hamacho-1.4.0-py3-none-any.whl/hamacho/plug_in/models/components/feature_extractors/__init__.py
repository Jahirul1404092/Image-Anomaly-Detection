"""Feature extractors."""



from .feature_extractor import FeatureExtractor

__all__ = ["FeatureExtractor"]
