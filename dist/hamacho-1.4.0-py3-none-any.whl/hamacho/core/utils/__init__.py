"""Helpers for downloading files, calculating metrics, computing anomaly maps, and visualization."""
