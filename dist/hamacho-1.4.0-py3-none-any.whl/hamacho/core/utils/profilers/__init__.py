"""Profilers for hamacho"""

from .cprofiler import HamachoProfiler

__all__ = [
    "HamachoProfiler",
]
