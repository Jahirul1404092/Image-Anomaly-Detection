"""Integration NNCF."""
