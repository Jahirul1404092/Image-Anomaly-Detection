"""Tools for anomaly score normalization."""

