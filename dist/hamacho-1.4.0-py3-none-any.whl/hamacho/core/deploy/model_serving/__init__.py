
from .torchserve_handler import TorchServeHandler

__all__ = [
    "TorchServeHandler"
]
