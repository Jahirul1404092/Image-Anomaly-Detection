"""Hamacho library for research and real life product anomaly detection."""


__version__ = "0.3.1"
